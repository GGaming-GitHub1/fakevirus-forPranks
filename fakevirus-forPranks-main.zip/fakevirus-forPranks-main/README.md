# fakevirus-forPranks
you can prank you friends white this FakeVirus! Have Fun :)
